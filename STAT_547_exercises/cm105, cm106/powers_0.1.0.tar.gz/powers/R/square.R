#' @title Square the input
#' @param x Vector of numerics
#' @return The vector x, squared
#' @export

square <- function(x) x^2

#in console, run:
#install.packages("roxygen2")
#library(devtools)
#document()
#then manually delete the NAMESPACE file from the root folder -> note that now that we added export, this is auto generated!


